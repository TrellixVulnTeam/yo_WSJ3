<?php
class Backend extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model( "Back_model" ); 
    }

    public function index(){
        echo "<h4>Acceso no permitido</h4>";
    }

    public function getpromociones(){
        $data = $this->Back_model->get_promociones();
        $obj[ "resultado" ] = $data != NULL;
        $obj[ "mensaje" ] = $obj[ "resultado" ] ?
            "Se recuperaron ".count( $data)." promocion(es)" : "No hay promociones registradas";
        $obj[ "promociones" ] = $data;

        echo json_encode( $obj );

    }

    public function borrapromocion(){
        $idpromocion = $this->input->post( "idpromocion" );
        $obj[ "resultado" ] = $this->Back_model->delete_promocion( $idpromocion );
        $obj[ "mensaje" ] = $obj[ "resultado" ] ?
            "Promocion eliminada" : "Imposible borrar promoción";
        

        echo json_encode( $obj );

    }

    public function cambiavigencia(){
        $idpromocion = $this->input->post( "idpromocion" );

        $obj[ "resultado" ]=$this->Back_model->change_promocion($idpromocion);
        $obj[ "mensaje" ]=$obj[ "resultado" ] ?
             "Vigencia cambiada" : "Imposible de la actualizar";

        echo json_encode($obj);

    }
}
?>